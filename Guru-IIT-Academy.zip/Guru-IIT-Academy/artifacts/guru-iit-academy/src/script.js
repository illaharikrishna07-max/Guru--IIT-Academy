const menuButton = document.querySelector('#menu-toggle');
const mobileNavigation = document.querySelector('#mobile-navigation');
const header = document.querySelector('#site-header');

function setMenuOpen(open) {
  if (!(menuButton instanceof HTMLButtonElement) || !(mobileNavigation instanceof HTMLElement)) return;
  menuButton.setAttribute('aria-expanded', String(open));
  menuButton.setAttribute('aria-label', open ? 'Close navigation menu' : 'Open navigation menu');
  mobileNavigation.setAttribute('aria-hidden', String(!open));
  mobileNavigation.inert = !open;
  mobileNavigation.classList.toggle('is-open', open);
  const icon = menuButton.querySelector('use');
  icon?.setAttribute('href', open ? '#icon-close' : '#icon-menu');
}

menuButton?.addEventListener('click', () => {
  setMenuOpen(menuButton.getAttribute('aria-expanded') !== 'true');
});

mobileNavigation?.querySelectorAll('a').forEach((link) => {
  link.addEventListener('click', () => setMenuOpen(false));
});

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && menuButton?.getAttribute('aria-expanded') === 'true') {
    setMenuOpen(false);
    menuButton.focus();
  }
});

function updateHeader() {
  header?.classList.toggle('is-scrolled', window.scrollY > 10);
}

window.addEventListener('scroll', updateHeader, { passive: true });
updateHeader();

const revealItems = document.querySelectorAll('.reveal');
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

if ('IntersectionObserver' in window && !reduceMotion) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add('is-visible');
      observer.unobserve(entry.target);
    });
  }, { threshold: 0.12 });
  revealItems.forEach((item) => observer.observe(item));
}

setMenuOpen(false);