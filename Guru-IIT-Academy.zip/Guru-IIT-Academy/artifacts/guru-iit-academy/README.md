# Guru IIT Academy

A responsive, single-page website for Guru IIT Academy. The page uses semantic HTML, CSS, and a small vanilla JavaScript file. It has no backend or database.

## Run locally

From the workspace root:

```sh
pnpm install
PORT=5173 BASE_PATH=/ pnpm --filter @workspace/guru-iit-academy run dev
```

## Director photos

The two original photos are installed here without altering their image data:

- `public/assets/images/director-professional.jpg` — hero and Director section
- `public/assets/images/director-natural.jpg` — About section

The professional portrait is used in the hero and Director sections. The natural portrait is used in the About section. Their display crops are controlled with CSS; the source photos remain unchanged.

## Update the site

- Page copy, navigation, contact details, and structured data are in `index.html`.
- Menu behavior and subtle scroll reveals are in `src/script.js`.
- Colors, spacing, typography, responsive layout, and motion are in `src/index.css`.
- Replace the map placeholder with the academy’s verified Google Maps embed URL when available. The current directions link searches the provided address without coordinates.
- Replace `https://YOUR-DOMAIN.example/` with the official website domain in `index.html`, `public/robots.txt`, and `public/sitemap.xml` before launch.
- Replace `public/favicon.svg` if the academy supplies a final logo.

Only add verified business details. Hours, results, testimonials, qualifications, and awards are intentionally omitted until confirmed.